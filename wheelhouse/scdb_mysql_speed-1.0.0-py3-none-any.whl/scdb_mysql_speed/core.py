"""High-level pooled MySQL operations and result conversion."""

from __future__ import annotations

import json
from contextlib import contextmanager
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Iterator, Literal, cast

import MySQLdb
from MySQLdb.cursors import Cursor, DictCursor

from .exceptions import SCDBQueryError, SCDBTransactionError
from .meta import SCDBMySQLMeta
from .pool import ConnectionPool

ResultFormat = Literal["tuple", "dict", "json", "dataframe", "df"]
Params = tuple[Any, ...] | list[Any] | dict[str, Any] | None


class SCDBMySQLSpeed:
    """Expose query, write, pagination, and transaction operations.

    Example:
        >>> meta = SCDBMySQLMeta(host="127.0.0.1", user="app_user", database="app")
        >>> with SCDBMySQLSpeed(meta) as db:
        ...     rows = db.fetch_all("SELECT 1")
    """

    def __init__(self, meta: SCDBMySQLMeta) -> None:
        self._meta = meta
        self._pool = ConnectionPool(meta)

    def fetch_all(
        self,
        sql: str,
        params: Params = None,
        result_format: ResultFormat = "tuple",
    ) -> Any:
        """Execute a query and return all rows in the selected format."""
        return self._fetch(sql, params, result_format, one=False)

    def fetch_one(
        self,
        sql: str,
        params: Params = None,
        result_format: ResultFormat = "tuple",
    ) -> Any:
        """Execute a query and return one row, or ``None`` when empty."""
        return self._fetch(sql, params, result_format, one=True)

    def fetch_page(
        self,
        sql: str,
        params: Params = None,
        *,
        page: int = 1,
        page_size: int = 100,
        result_format: ResultFormat = "tuple",
    ) -> Any:
        """Append a validated ``LIMIT`` clause and fetch one page."""
        if page < 1:
            raise ValueError("page 必须大于等于 1")
        if page_size < 1:
            raise ValueError("page_size 必须大于等于 1")
        offset = (page - 1) * page_size
        paged_sql = f"{sql.rstrip().rstrip(';')} LIMIT {offset}, {page_size}"
        return self.fetch_all(paged_sql, params, result_format)

    def execute(self, sql: str, params: Params = None) -> int:
        """Execute one write statement, committing or rolling back automatically."""
        try:
            with self._pool.connection() as conn:
                conn.autocommit(False)
                cursor = conn.cursor()
                try:
                    cursor.execute(sql, params)
                    affected = int(cursor.rowcount)
                    conn.commit()
                    return affected
                except Exception:
                    conn.rollback()
                    raise
                finally:
                    cursor.close()
        except MySQLdb.Error as exc:
            raise SCDBQueryError(f"SQL 执行失败: {exc}") from exc

    def execute_many(
        self,
        sql: str,
        params_list: list[tuple[Any, ...] | list[Any] | dict[str, Any]],
    ) -> int:
        """Execute a parameterized write statement for every parameter set."""
        if not params_list:
            return 0
        try:
            with self._pool.connection() as conn:
                conn.autocommit(False)
                cursor = conn.cursor()
                try:
                    cursor.executemany(sql, params_list)
                    affected = int(cursor.rowcount)
                    conn.commit()
                    return affected
                except Exception:
                    conn.rollback()
                    raise
                finally:
                    cursor.close()
        except MySQLdb.Error as exc:
            raise SCDBQueryError(f"批量 SQL 执行失败: {exc}") from exc

    @contextmanager
    def transaction(self, *, dict_cursor: bool = False) -> Iterator[Cursor]:
        """Yield one cursor and commit/rollback the surrounding transaction."""
        try:
            with self._pool.connection() as conn:
                conn.autocommit(False)
                cursor = conn.cursor(DictCursor if dict_cursor else Cursor)
                try:
                    yield cast(Cursor, cursor)
                    conn.commit()
                except Exception:
                    try:
                        conn.rollback()
                    except Exception as rollback_exc:
                        raise SCDBTransactionError(
                            f"事务失败且回滚失败: {rollback_exc}"
                        ) from rollback_exc
                    raise
                finally:
                    cursor.close()
        except MySQLdb.Error as exc:
            raise SCDBTransactionError(f"事务操作失败: {exc}") from exc

    def test_connection(self) -> bool:
        """Return ``True`` only when ``SELECT 1`` succeeds."""
        try:
            return self.fetch_one("SELECT 1") == (1,)
        except Exception:
            return False

    def close(self) -> None:
        """Close the underlying connection pool."""
        self._pool.close()

    def __enter__(self) -> SCDBMySQLSpeed:
        """Return this database facade for use in a ``with`` statement."""
        return self

    def __exit__(self, *_exc: object) -> None:
        """Close the pool on context-manager exit."""
        self.close()

    def __repr__(self) -> str:
        """Return endpoint identity without exposing credentials."""
        return f"SCDBMySQLSpeed(host={self._meta.host!r}, database={self._meta.database!r})"

    def _fetch(
        self,
        sql: str,
        params: Params,
        result_format: ResultFormat,
        *,
        one: bool,
    ) -> Any:
        normalized = "dataframe" if result_format == "df" else result_format
        if normalized not in {"tuple", "dict", "json", "dataframe"}:
            raise ValueError(f"不支持的 result_format: {result_format!r}")
        cursor_class = Cursor if normalized == "tuple" else DictCursor
        try:
            with self._pool.connection() as conn:
                conn.autocommit(True)
                cursor = conn.cursor(cursor_class)
                try:
                    cursor.execute(sql, params)
                    raw = cursor.fetchone() if one else cursor.fetchall()
                    columns = [item[0] for item in (cursor.description or ())]
                finally:
                    cursor.close()
        except MySQLdb.Error as exc:
            raise SCDBQueryError(f"查询执行失败: {exc}") from exc
        return self._convert(raw, columns, normalized, one=one)

    @staticmethod
    def _convert(raw: Any, columns: list[str], result_format: str, *, one: bool) -> Any:
        if result_format == "tuple":
            return raw
        if one:
            dict_rows = [] if raw is None else [dict(raw)]
        else:
            dict_rows = [dict(row) for row in raw]
        if result_format == "dict":
            return dict_rows[0] if one and dict_rows else (None if one else dict_rows)
        if result_format == "json":
            value: Any = dict_rows[0] if one and dict_rows else (None if one else dict_rows)
            return json.dumps(value, ensure_ascii=False, default=_json_default)
        if result_format == "dataframe":
            try:
                import pandas as pd
            except ImportError as exc:
                raise ImportError(
                    "DataFrame 返回格式需要 pandas；请安装 scdb-mysql-speed[dataframe]"
                ) from exc
            return pd.DataFrame(dict_rows, columns=columns or None)
        raise AssertionError("unreachable")


def _json_default(value: object) -> str:
    """Serialize common MySQL scalar types without losing JSON validity."""
    if isinstance(value, (date, datetime, Decimal)):
        return str(value)
    if isinstance(value, (bytes, bytearray)):
        return bytes(value).decode("utf-8", errors="replace")
    return str(value)

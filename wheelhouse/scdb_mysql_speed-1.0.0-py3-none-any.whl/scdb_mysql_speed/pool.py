"""A small, thread-safe MySQLdb connection pool."""

from __future__ import annotations

import logging
import queue
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Iterator, Protocol

import MySQLdb

from .exceptions import SCDBConnectionError, SCDBPoolError
from .meta import SCDBMySQLMeta

logger = logging.getLogger(__name__)


class ConnectionLike(Protocol):
    """The subset of a MySQLdb connection used by the pool."""

    def ping(self, reconnect: bool = ...) -> Any: ...

    def close(self) -> Any: ...


@dataclass(slots=True)
class _PooledConnection:
    connection: ConnectionLike
    created_at: float


class ConnectionPool:
    """Manage reusable MySQLdb connections with a hard concurrency bound.

    Example:
        >>> pool = ConnectionPool(meta)
        >>> with pool.connection() as conn:
        ...     conn.ping()
        >>> pool.close()
    """

    def __init__(self, meta: SCDBMySQLMeta) -> None:
        self._meta = meta
        self._idle: queue.LifoQueue[_PooledConnection] = queue.LifoQueue(
            maxsize=meta.max_connections
        )
        self._slots = threading.BoundedSemaphore(meta.max_connections)
        self._state_lock = threading.Lock()
        self._closed = False

        for _ in range(meta.pool_size):
            try:
                self._idle.put_nowait(self._new_connection())
            except SCDBConnectionError:
                logger.warning("连接池预连接失败，将在首次使用时重试", exc_info=True)
                break

    @contextmanager
    def connection(self) -> Iterator[ConnectionLike]:
        """Borrow a healthy connection and return it automatically."""
        with self._state_lock:
            if self._closed:
                raise SCDBPoolError("连接池已关闭")

        if not self._slots.acquire(timeout=self._meta.pool_timeout):
            raise SCDBPoolError(f"获取连接超时（{self._meta.pool_timeout:g} 秒）")

        pooled: _PooledConnection | None = None
        try:
            pooled = self._acquire_healthy()
            yield pooled.connection
        except BaseException:
            if pooled is not None:
                if self._is_alive(pooled.connection):
                    self._release(pooled)
                else:
                    self._safe_close(pooled.connection)
                pooled = None
            raise
        finally:
            if pooled is not None:
                self._release(pooled)
            self._slots.release()

    get_connection = connection

    def close(self) -> None:
        """Close every idle connection and permanently close this pool."""
        with self._state_lock:
            self._closed = True
        while True:
            try:
                pooled = self._idle.get_nowait()
            except queue.Empty:
                break
            self._safe_close(pooled.connection)

    close_all = close

    @property
    def idle_count(self) -> int:
        """Return the approximate number of currently idle connections."""
        return self._idle.qsize()

    @property
    def closed(self) -> bool:
        """Return whether :meth:`close` has been called."""
        with self._state_lock:
            return self._closed

    def _new_connection(self) -> _PooledConnection:
        try:
            conn = MySQLdb.connect(**self._meta.to_connect_kwargs())
        except Exception as exc:
            raise SCDBConnectionError(f"创建 MySQL 连接失败: {exc}") from exc
        return _PooledConnection(conn, time.monotonic())

    def _acquire_healthy(self) -> _PooledConnection:
        while True:
            try:
                pooled = self._idle.get_nowait()
            except queue.Empty:
                return self._new_connection()
            if self._is_expired(pooled) or not self._is_alive(pooled.connection):
                self._safe_close(pooled.connection)
                continue
            return pooled

    def _release(self, pooled: _PooledConnection) -> None:
        if self.closed or not self._is_alive(pooled.connection):
            self._safe_close(pooled.connection)
            return
        try:
            self._idle.put_nowait(pooled)
        except queue.Full:
            self._safe_close(pooled.connection)

    def _is_expired(self, pooled: _PooledConnection) -> bool:
        return time.monotonic() - pooled.created_at >= self._meta.pool_recycle

    @staticmethod
    def _is_alive(connection: ConnectionLike) -> bool:
        try:
            connection.ping(False)
        except Exception:
            return False
        return True

    @staticmethod
    def _safe_close(connection: ConnectionLike) -> None:
        try:
            connection.close()
        except Exception:
            logger.debug("关闭 MySQL 连接失败", exc_info=True)

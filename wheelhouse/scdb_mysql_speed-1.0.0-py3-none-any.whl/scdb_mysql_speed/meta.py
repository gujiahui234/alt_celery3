"""Immutable MySQL connection and pool configuration."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class SCDBMySQLMeta:
    """Describe one MySQL endpoint and its connection pool.

    Example:
        >>> meta = SCDBMySQLMeta(host="127.0.0.1", user="app_user", database="app_db")
        >>> meta.max_connections
        15
    """

    host: str
    port: int = 3306
    user: str = "app_user"
    password: str = ""
    database: str = ""
    charset: str = "utf8mb4"
    connect_timeout: int = 10
    read_timeout: int = 30
    write_timeout: int = 30
    pool_size: int = 5
    pool_max_overflow: int = 10
    pool_timeout: float = 30.0
    pool_recycle: float = 3600.0

    def __post_init__(self) -> None:
        """Validate values before any network connection is attempted."""
        if not self.host.strip():
            raise ValueError("host 不能为空")
        if not 1 <= self.port <= 65535:
            raise ValueError("port 必须在 1..65535 之间")
        if not self.user.strip():
            raise ValueError("user 不能为空")
        if self.pool_size < 0:
            raise ValueError("pool_size 不能小于 0")
        if self.pool_max_overflow < 0:
            raise ValueError("pool_max_overflow 不能小于 0")
        if self.max_connections < 1:
            raise ValueError("连接池最大连接数必须至少为 1")
        for name in (
            "connect_timeout",
            "read_timeout",
            "write_timeout",
            "pool_timeout",
            "pool_recycle",
        ):
            if getattr(self, name) <= 0:
                raise ValueError(f"{name} 必须大于 0")

    @property
    def max_connections(self) -> int:
        """Return the hard upper bound for simultaneous borrowed connections."""
        return self.pool_size + self.pool_max_overflow

    def to_connect_kwargs(self) -> dict[str, Any]:
        """Return keyword arguments accepted by ``MySQLdb.connect``.

        Example:
            >>> SCDBMySQLMeta(host="db.local", database="app").to_connect_kwargs()["db"]
            'app'
        """
        return {
            "host": self.host,
            "port": self.port,
            "user": self.user,
            "passwd": self.password,
            "db": self.database,
            "charset": self.charset,
            "connect_timeout": self.connect_timeout,
            "read_timeout": self.read_timeout,
            "write_timeout": self.write_timeout,
        }

    def __repr__(self) -> str:
        """Return a representation that never contains the password."""
        return (
            f"SCDBMySQLMeta(host={self.host!r}, port={self.port}, user={self.user!r}, "
            f"database={self.database!r}, pool_size={self.pool_size}, "
            f"pool_max_overflow={self.pool_max_overflow})"
        )

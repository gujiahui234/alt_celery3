"""Public API for :mod:`scdb_mysql_speed`."""

from .core import SCDBMySQLSpeed
from .exceptions import (
    SCDBConnectionError,
    SCDBError,
    SCDBPoolError,
    SCDBQueryError,
    SCDBTransactionError,
)
from .meta import SCDBMySQLMeta

__all__ = [
    "SCDBConnectionError",
    "SCDBError",
    "SCDBMySQLMeta",
    "SCDBMySQLSpeed",
    "SCDBPoolError",
    "SCDBQueryError",
    "SCDBTransactionError",
]

__version__ = "1.0.0"

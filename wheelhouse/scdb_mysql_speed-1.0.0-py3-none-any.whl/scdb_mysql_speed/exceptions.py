"""Package-specific exception hierarchy."""


class SCDBError(Exception):
    """Base class for all package errors."""


class SCDBConnectionError(SCDBError):
    """A physical MySQL connection could not be created or validated."""


class SCDBPoolError(SCDBError):
    """The connection pool is closed, exhausted, or otherwise unavailable."""


class SCDBQueryError(SCDBError):
    """A query or write operation failed."""


class SCDBTransactionError(SCDBError):
    """A transaction could not be committed or rolled back safely."""
